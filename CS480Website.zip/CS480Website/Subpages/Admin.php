<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "sab";
					
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}
	
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		$deletedUser = $_POST['deleted'];
		$username = $_COOKIE['adminUsername'];
		$getID = "SELECT admin_ID FROM admin WHERE user_name = '$username';";
		$id = $conn->query($getID);
		$id = $id->fetch_assoc();
		$id = $id['admin_ID'];
		
		$users = "SELECT * FROM user WHERE admin_ID = '$id';";
		$allUsers = $conn->query($users);
		
		while($currUser = $allUsers->fetch_assoc()) {
			$toDelete = $currUser['user_name'];
			
			if($deletedUser === $toDelete) {
				$remove = "DELETE FROM user WHERE user_name = '$toDelete';";
				$conn->query($remove);
			}
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">

        <!--CSS and JS file-->
		<link href="../CSS/styles.css" rel="stylesheet">
        <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
		<script src="../JavaScript/jScript.js" defer></script>
        

        <!--Webpage name-->
		<title>Account Page</title>

        <!--Favicon-->
        <link id="favicon" rel="icon" href="../Images/penrose.png">
        
        
        
	</head>
	<body>

		<header class="pageTop">
			<a href="../Index.php"><img src="../Images/penrose.png" alt="SAB Logo" id="Logo"></a>
			<h1>SAB Financial</h1>
        </header>

		<div class="content">
			<div class="adminPage">
				<h1> Welcome, <?php echo $_COOKIE['adminUsername']; ?></h1>
				<br><br>
				<h2 style="margin-left: -40%;">Your users</h2>
			</div>
			<table>
				<tr>
					<th>Username</th>
					<th>Email</th>
					<th>User ID</th>
				</tr>
				<?php 
					$username = $_COOKIE['adminUsername'];
					$getID = "SELECT admin_ID FROM admin WHERE user_name = '$username';";
					$id = $conn->query($getID);
					$id = $id->fetch_assoc();
					$id = $id['admin_ID'];
					
					$users = "SELECT * FROM user WHERE admin_ID = '$id';";
					$users = $conn->query($users);
					
					while($row = $users->fetch_assoc()) {
						echo "<tr>";
							echo "<td>" . $row['user_name'] . "</td>";
							echo "<td>" . $row['email'] . "</td>";
							echo "<td>" . $row['userID'] . "</td>";
						echo "</tr>";
					}
				?>
			</table>
		</div>
		<form method="post" action="#" id="deleted">
			<h2>Remove a User</h2>
			<select style="width: 80%;" name="deleted">
				<?php	
						$users = "SELECT * FROM user WHERE admin_ID = '$id';";
						$users = $conn->query($users);

						while($row = $users->fetch_assoc()) {
							echo '<option value="' . $row['user_name'] . '">' . $row['user_name'] . '</option>';
						}
					?>
			</select>
			<br>
			<input type="submit" value="Delete">
		</form>
	</body>
	<footer>
		<p id="footerText">Copyright All rights reserved.</p>
	</footer>
</html>